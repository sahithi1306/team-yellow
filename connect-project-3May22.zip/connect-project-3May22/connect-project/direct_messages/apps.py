from django.apps import AppConfig


class DirectMessagesConfig(AppConfig):
    name = 'direct_messages'
