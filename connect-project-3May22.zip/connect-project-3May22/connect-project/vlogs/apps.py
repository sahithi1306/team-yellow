from django.apps import AppConfig


class PhotoBlogConfig(AppConfig):
    name = 'vlogs'

    def ready(self):
        import vlogs.signals
